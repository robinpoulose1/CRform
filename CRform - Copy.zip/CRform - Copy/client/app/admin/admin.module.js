'use strict';

angular.module('crformApp.admin', ['crformApp.auth', 'ui.router']);
