'use strict';

(function() {

  class HomeController {

  }

  angular.module('crformApp')
    .component('home', {
      templateUrl: 'app/home/home.html',
      controller: HomeController
    });
})();
