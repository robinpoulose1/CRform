'use strict';

angular.module('crformApp.admin')
  .config(function($stateProvider) {
    $stateProvider.state('main', {
      url: '/main',
        controller: 'AdminController',
             controllerAs: 'admin',
     authenticate: 'user',
      template: '<main></main>'
        
    });
  });
