'use strict';

(function () {

    class MainController {

        constructor($http, $scope, socket,Auth,User) {
            this.users = User.query();
            this.$http = $http;
            this.socket = socket;
            this.awesomeThings = [];
           
            this.isLoggedIn = Auth.isLoggedIn;
    this.isAdmin = Auth.isAdmin;
    this.isUser = Auth.isUser;  
    this.getCurrentUser = Auth.getCurrentUser;
    this.Auth = Auth;
 

            var vm = this;
	/*vm.users = []; //declare an empty array*/
	vm.pageno = 1; // initialize page no to 1
	vm.total_count = 224;
	vm.itemsPerPage =10; //this could be a dynamic value from a drop down
            

            $scope.$on('$destroy', function () {
                socket.unsyncUpdates('thing');
            });


        }

   /*     $onInit(thing) {
            this.$http.get('/api/things/:id',{params: {requester:"Admin"}} )
                .then(response => {
                    this.awesomeThings = response.data;
                    this.socket.syncUpdates('thing', this.awesomeThings);
                });
        }*/

        

      $onInit(thing ) {
            this.$http.get('/api/things/:id/:itemsPerPage/:pageno',{ 
                params : { requester: this.getCurrentUser().name, itemsPerPage: 10, pageno: 1 }} )




                .then(response => {
                    this.awesomeThings = response.data;
                    this.socket.syncUpdates('thing', this.awesomeThings);
                });
        }



/*this.$http({
    url: '/api/things/:id', 
    method: "GET",
    params: {requester:'Admin'}
 })*/


getData(pageno){

    this.$http.get('/api/things/:id/:itemsPerPage/:pageno',{ 
                params : { requester: this.getCurrentUser().name, itemsPerPage: 10, pageno: pageno}} )
                   .then(response => {
                    this.awesomeThings = response.data;
                    this.socket.syncUpdates('thing', this.awesomeThings);
                });


}




   addThing() {
            if (this.newReqP) {
                
                this.$http.post('/api/things', {
                   created_at : Date.now(),
                  priority: this.newReqP,
                 system : this.newReqSys,
                 assignTo : this.assignTo,
              /*   requester: Auth,*/
               /* requester: this.Auth.getCurrentUser().name,*/
               requester: this.getCurrentUser().name,      ////////////////send to api to db
                 department : this.newReqDpt,
                 title : this.newReqTitle
                    
                });
                this.newReqP = '';
                 this.newReqP= '';
                this.newReqSys= '';
                    this.newReqRname= '';
                    this.newReqDpt= '';
                this.newReqTitle= '';
            }
        }

     

        deleteThing(thing) {
            this.$http.delete('/api/things/' + thing._id);
        }
    }

    angular.module('crformApp')
        .component('main', {
            templateUrl: 'app/main/main.html',
            controller: MainController
        });
})();