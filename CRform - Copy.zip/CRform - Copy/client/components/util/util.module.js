'use strict';

angular.module('crformApp.util', []);
