'use strict';

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {

  /////

  var NavbarController =
  //end-non-standard

  //start-non-standard
  function NavbarController(Auth) {
    _classCallCheck(this, NavbarController);

    this.isLoggedIn = Auth.isLoggedIn;
    this.isAdmin = Auth.isAdmin;
    this.isUser = Auth.isUser;
    this.getCurrentUser = Auth.getCurrentUser;
  };

  angular.module('crformApp').controller('NavbarController', NavbarController).directive('navNotify', function () {
    return {
      scope: {},
      restrict: 'A',
      /*template : 'i am x',*/
      link: function link(scope, element, attrs) {
        $(document).ready(function () {
          $('#notificationLink').click(function () {
            $('#notificationContainer').fadeToggle(300);
            $('#notification_count').fadeOut('slow');
            $('#notificationLink > i.fa-bell').addClass('fa-bell-o');
            $('#notificationLink > i.fa-bell').removeClass('fa-bell');
            return false;
          });

          //Document Click hiding the popup 
          $(document).click(function () {
            $("#notificationContainer").hide();
          });

          //Popup on click
          $("#notificationContainer").click(function () {
            return false;
          });

          //$('#AddNew').on('click', function () {
          //    $('#notificationsBody ul').append('<li>New Message</li>');
          //});
        });
      }
    };
  });
})();
//# sourceMappingURL=navbar.controller.js.map
