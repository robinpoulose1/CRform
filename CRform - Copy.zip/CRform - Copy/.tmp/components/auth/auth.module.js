'use strict';

angular.module('crformApp.auth', ['crformApp.constants', 'crformApp.util', 'ngCookies', 'ui.router']).config(function ($httpProvider) {
  $httpProvider.interceptors.push('authInterceptor');
});
//# sourceMappingURL=auth.module.js.map
