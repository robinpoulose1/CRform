'use strict';

angular.module('crformApp.admin', ['crformApp.auth', 'ui.router']);
//# sourceMappingURL=admin.module.js.map
