'use strict';

angular.module('crformApp').config(function ($stateProvider) {
  $stateProvider.state('home', {
    url: '/',
    template: '<home></home>'
  });
});
//# sourceMappingURL=home.js.map
