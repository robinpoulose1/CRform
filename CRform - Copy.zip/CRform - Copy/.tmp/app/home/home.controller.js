'use strict';

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
  var HomeController = function HomeController() {
    _classCallCheck(this, HomeController);
  };

  angular.module('crformApp').component('home', {
    templateUrl: 'app/home/home.html',
    controller: HomeController
  });
})();
//# sourceMappingURL=home.controller.js.map
