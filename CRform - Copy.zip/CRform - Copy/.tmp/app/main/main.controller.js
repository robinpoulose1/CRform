'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
    var MainController = function () {
        function MainController($http, $scope, socket, Auth, User) {
            _classCallCheck(this, MainController);

            this.users = User.query();
            this.$http = $http;
            this.socket = socket;
            this.awesomeThings = [];

            this.isLoggedIn = Auth.isLoggedIn;
            this.isAdmin = Auth.isAdmin;
            this.isUser = Auth.isUser;
            this.getCurrentUser = Auth.getCurrentUser;
            this.Auth = Auth;

            var vm = this;
            /*vm.users = []; //declare an empty array*/
            vm.pageno = 1; // initialize page no to 1
            vm.total_count = 224;
            vm.itemsPerPage = 10; //this could be a dynamic value from a drop down

            $scope.$on('$destroy', function () {
                socket.unsyncUpdates('thing');
            });
        }

        /*     $onInit(thing) {
                 this.$http.get('/api/things/:id',{params: {requester:"Admin"}} )
                     .then(response => {
                         this.awesomeThings = response.data;
                         this.socket.syncUpdates('thing', this.awesomeThings);
                     });
             }*/

        _createClass(MainController, [{
            key: '$onInit',
            value: function $onInit(thing) {
                var _this = this;

                this.$http.get('/api/things/:id/:itemsPerPage/:pageno', {
                    params: { requester: this.getCurrentUser().name, itemsPerPage: 10, pageno: 1 } }).then(function (response) {
                    _this.awesomeThings = response.data;
                    _this.socket.syncUpdates('thing', _this.awesomeThings);
                });
            }

            /*this.$http({
                url: '/api/things/:id', 
                method: "GET",
                params: {requester:'Admin'}
             })*/

        }, {
            key: 'getData',
            value: function getData(pageno) {
                var _this2 = this;

                this.$http.get('/api/things/:id/:itemsPerPage/:pageno', {
                    params: { requester: this.getCurrentUser().name, itemsPerPage: 10, pageno: pageno } }).then(function (response) {
                    _this2.awesomeThings = response.data;
                    _this2.socket.syncUpdates('thing', _this2.awesomeThings);
                });
            }
        }, {
            key: 'addThing',
            value: function addThing() {
                if (this.newReqP) {

                    this.$http.post('/api/things', {
                        created_at: Date.now(),
                        priority: this.newReqP,
                        system: this.newReqSys,
                        assignTo: this.assignTo,
                        /*   requester: Auth,*/
                        /* requester: this.Auth.getCurrentUser().name,*/
                        requester: this.getCurrentUser().name, ////////////////send to api to db
                        department: this.newReqDpt,
                        title: this.newReqTitle

                    });
                    this.newReqP = '';
                    this.newReqP = '';
                    this.newReqSys = '';
                    this.newReqRname = '';
                    this.newReqDpt = '';
                    this.newReqTitle = '';
                }
            }
        }, {
            key: 'deleteThing',
            value: function deleteThing(thing) {
                this.$http.delete('/api/things/' + thing._id);
            }
        }]);

        return MainController;
    }();

    angular.module('crformApp').component('main', {
        templateUrl: 'app/main/main.html',
        controller: MainController
    });
})();
//# sourceMappingURL=main.controller.js.map
