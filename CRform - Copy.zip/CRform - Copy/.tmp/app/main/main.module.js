'use strict';

angular.module('crformApp.admin', ['crformApp.auth', 'ui.router', 'angularUtils.directives.dirPagination']);
//# sourceMappingURL=main.module.js.map
