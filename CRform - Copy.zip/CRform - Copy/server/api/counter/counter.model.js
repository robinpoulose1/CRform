/*
'use strict';

import mongoose from 'mongoose';

module.exports = mongoose.model('Counter', {
    _id: String,
    sequence_value: Number
});

*/


'use strict';

import mongoose from 'mongoose';

var counterSchema = new mongoose.Schema({
  _id: String,
    sequence_value: Number
});

export default mongoose.model('counter', counterSchema);
