'use strict';

import mongoose from 'mongoose';

var ThingSchema = new mongoose.Schema({
  created_at: {type: Date, default: Date.now},
  priority: String,
  assignTo: String,
   system: String,
  requester: String,
  department: String,
  title: String,
  status: {type: String, default: 'Open'},
/*  crtitle: String,
  priority: String,
  system: String,
  requester: String,
  Department: String*/
      
  active: Boolean
});

export default mongoose.model('Thing', ThingSchema);
